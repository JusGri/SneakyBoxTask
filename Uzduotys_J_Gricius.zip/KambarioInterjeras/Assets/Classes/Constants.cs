public static class Constants
{
    public const string untagged = "Untagged";
    public const string surfaceTag = "Surface";
    public const string placeableTag = "Placeable";
    public const string floorName = "Floor";
    public const string wall1Name = "wall1";
    public const string wall2Name = "wall2";
}
