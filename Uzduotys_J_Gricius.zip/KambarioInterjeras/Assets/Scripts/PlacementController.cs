﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlacementController : MonoBehaviour
{
    [SerializeField]
    private GameObject placeableObjectPrefab1;
    [SerializeField]
    private GameObject placeableObjectPrefab2;
    [SerializeField]
    private GameObject placeableObjectPrefab3;
    [SerializeField]
    private GameObject objectList;

    [SerializeField]
    private KeyCode newObjectHotKey = KeyCode.I;
    [SerializeField]
    private KeyCode CancelKey = KeyCode.C;
    [SerializeField]
    private KeyCode ExitKey = KeyCode.Escape;

    [SerializeField]
    private KeyCode RotateLeftKey = KeyCode.LeftArrow;
    [SerializeField]
    private KeyCode RotateRightKey = KeyCode.RightArrow;

    //UI elements
    //text
    [SerializeField]
    private Text warningText;

    private GameObject currentPlaceableObj;

    //private void Start()
    //{
    //    warningText.text = "";
    //}

    // Update is called once per frame
    private void Update()
    {
        HandleNewObjectPlacement();

        if (currentPlaceableObj != null)
        {
            MoveObjectOnMouse();
            RotateObject();
            PlaceIfClicked();
        }

        HandlePlacementCancellation();
        HandleExitApp();
    }

    private void HandlePlacementCancellation()
    {
        if (Input.GetKeyDown(CancelKey))
        {
            Destroy(currentPlaceableObj);
        }
    }

    private void HandleExitApp()
    {
        if (Input.GetKeyDown(ExitKey))
        {
            Application.Quit();
        }
    }

    private void PlaceIfClicked()
    {
        Ray mouseRay = Camera.main.ScreenPointToRay(Input.mousePosition);

        RaycastHit hitInfo;
        if (Physics.Raycast(mouseRay, out hitInfo))
        {
            if (Input.GetMouseButtonDown(0) && hitInfo.transform.gameObject.tag != Constants.placeableTag)
            {
                currentPlaceableObj.transform.gameObject.tag = Constants.placeableTag;
                currentPlaceableObj = null;
            }
            else if(Input.GetMouseButtonDown(0) && hitInfo.transform.gameObject.tag == Constants.placeableTag)
            {
                Debug.Log("Can't place an object on another object");
                warningText.color = Color.red;
                warningText.text="Can't place on furniture";
            }
        }
    }

    private void RotateObject()
    {
        if (Input.GetKeyDown(RotateLeftKey))
        {
            currentPlaceableObj.transform.Rotate(Vector3.up, 45f);
        }
        if (Input.GetKeyDown(RotateRightKey))
        {
            currentPlaceableObj.transform.Rotate(Vector3.up, -45f);
        }
    }

    private void MoveObjectOnMouse()
    {
        Ray mouseRay = Camera.main.ScreenPointToRay(Input.mousePosition);

        RaycastHit hitInfo;

        if (Physics.Raycast(mouseRay, out hitInfo))
        {
            if (hitInfo.transform.gameObject.tag == Constants.surfaceTag)
            {
                if (hitInfo.transform.gameObject.name == Constants.floorName)
                {
                    currentPlaceableObj.transform.position = new Vector3(hitInfo.point.x, hitInfo.point.y + currentPlaceableObj.transform.localScale.y/2, hitInfo.point.z); ;
                }
                else if (hitInfo.transform.gameObject.name == Constants.wall1Name)
                {
                    currentPlaceableObj.transform.position = new Vector3(hitInfo.point.x, currentPlaceableObj.transform.localScale.y / 2, hitInfo.point.z - currentPlaceableObj.transform.localScale.z / 2);
                }
                else if (hitInfo.transform.gameObject.name == Constants.wall2Name)
                {
                    currentPlaceableObj.transform.position = new Vector3(hitInfo.point.x - currentPlaceableObj.transform.localScale.x / 2, currentPlaceableObj.transform.localScale.y / 2, hitInfo.point.z);
                }
            }
        }
    }

    private void HandleNewObjectPlacement()
    {
        if (Input.GetKeyDown(newObjectHotKey))
        {
            if (!objectList.activeSelf)
            {
                objectList.SetActive(true);
            }
            else
            {
                objectList.SetActive(false);
            }
        }
    }

    public GameObject getCurrentPlaceable()
    {
        return currentPlaceableObj;
    }

    public void setCurrentPlaceable(GameObject newPlaceable)
    {
        this.currentPlaceableObj = newPlaceable;
    }

    public void PlaceObject1()
    {
        if (currentPlaceableObj == null)
        {
            currentPlaceableObj = Instantiate(placeableObjectPrefab1);
        }
        else
        {
            Destroy(currentPlaceableObj);
            currentPlaceableObj = Instantiate(placeableObjectPrefab1);
        }
    }

    public void PlaceObject2()
    {
        if (currentPlaceableObj == null)
        {
            currentPlaceableObj = Instantiate(placeableObjectPrefab2);
        }
        else
        {
            Destroy(currentPlaceableObj);
            currentPlaceableObj = Instantiate(placeableObjectPrefab2);
        }
    }

    public void PlaceObject3()
    {
        if (currentPlaceableObj == null)
        {
            currentPlaceableObj = Instantiate(placeableObjectPrefab3);
        }
        else
        {
            Destroy(currentPlaceableObj);
            currentPlaceableObj = Instantiate(placeableObjectPrefab3);
        }
    }
}
