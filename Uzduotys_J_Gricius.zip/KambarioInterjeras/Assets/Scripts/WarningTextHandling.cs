using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WarningTextHandling : MonoBehaviour
{
    [SerializeField]
    private Text warning;

    // Start is called before the first frame update
    void Start()
    {
        warning.text = "Press \"I\" to open furniture list";
    }

    // Update is called once per frame
    void Update()
    {
        if(warning.text != "")
        {
            CleanText();
        }
    }

    private void CleanText()
    {
        StartCoroutine(WaitBeforeCleaning());
    }

    private IEnumerator WaitBeforeCleaning()
    {
        yield return new WaitForSeconds(3);
        this.warning.text = "";
    }
}
