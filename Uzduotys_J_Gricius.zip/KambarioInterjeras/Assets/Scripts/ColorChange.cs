using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColorChange : MonoBehaviour
{
    [SerializeField]
    Renderer ColoredObject;
    [SerializeField]
    private Color color = new Color(0.5f, 0.5f, 0.5f);

    void Update()
    {
        ColoredObject.material.color = color;
    }

    public Color getColor()
    {
        return color;
    }

    public void setColor(Color color)
    {
        this.color = color;
    }

}
