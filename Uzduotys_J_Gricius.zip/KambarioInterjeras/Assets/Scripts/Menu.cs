using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Menu : MonoBehaviour
{
    //buttons
    [SerializeField]
    private Button moveButton;
    [SerializeField]
    private Button deleteButton;
    [SerializeField]
    private Button colorButton;
    [SerializeField]
    private Button saveButton;

    //sliders
    [SerializeField]
    private Slider sliderR;
    [SerializeField]
    private Slider sliderG;
    [SerializeField]
    private Slider sliderB;

    //panels
    [SerializeField]
    private GameObject optionsPanel;
    [SerializeField]
    private GameObject colorPanel;

    //controller refferences
    [SerializeField]
    private PlacementController cont;
    private ColorChange col;

    private GameObject editableObject;

    // Update is called once per frame
    void Update()
    {
        OpenOptions();
        if (colorPanel.activeSelf)
        {
            //col = editableObject.GetComponent<ColorChange>();
            Color newColor = new Color(sliderR.value, sliderG.value, sliderB.value);
            col.setColor(newColor);
        }
    }

    public void CloseOptions()
    {
        optionsPanel.SetActive(false);
        editableObject = null;
    }

    public void SaveColor()
    {
        colorPanel.SetActive(false);
    }

    public void OpenColors()
    {
        if (editableObject != null)
        {
            col = editableObject.GetComponent<ColorChange>();
            optionsPanel.SetActive(false);
            colorPanel.SetActive(true);
            sliderR.value = col.getColor().r;
            sliderG.value = col.getColor().g;
            sliderB.value = col.getColor().b;
        }
    }

    public void DeleteObject()
    {
        if (editableObject != null)
        {
            Destroy(editableObject);
            optionsPanel.SetActive(false);
        }
    }

    public void MoveObject()
    {
        if (editableObject != null)
        {
            editableObject.transform.gameObject.tag = Constants.untagged;
            cont.setCurrentPlaceable(editableObject);
            optionsPanel.SetActive(false);
            editableObject = null;
        }
    }

    private void OpenOptions()
    {
        if (cont.getCurrentPlaceable() == null)
        {
            Ray mouseRay = Camera.main.ScreenPointToRay(Input.mousePosition);

            RaycastHit hitInfo;

            if (Physics.Raycast(mouseRay, out hitInfo))
            {
                if(Input.GetMouseButtonDown(1) && hitInfo.transform.gameObject.tag == Constants.placeableTag)
                {
                    editableObject = hitInfo.transform.gameObject;
                    optionsPanel.SetActive(true);
                }
            }
        }
    }
}
