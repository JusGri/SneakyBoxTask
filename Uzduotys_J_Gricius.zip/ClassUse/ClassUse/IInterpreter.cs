﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassUse
{
    public interface IInterpreter
    {
        /// <summary>
        /// I pass nothing into the method, because when another class inherits it
        /// I want to be able to choose what value(int,string,etc.) to interpret
        /// </summary>
        /// <returns></returns>
        public abstract string InterpretValue();
    }


}
