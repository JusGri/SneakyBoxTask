﻿using System;

namespace ClassUse
{
    class Program
    {
        static void Main(string[] args)
        {
            SBInterpreter interpreter = new SBInterpreter();
            for (int i = 1; i<=100; i++)
            {
                interpreter.SetNumber(i);
                Console.WriteLine(interpreter.InterpretValue());
            }
        }
    }
}
