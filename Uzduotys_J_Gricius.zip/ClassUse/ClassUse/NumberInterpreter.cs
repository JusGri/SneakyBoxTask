﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace ClassUse
{
    public abstract class NumberInterpreter : IInterpreter
    {
        private int Number;

        public void SetNumber(int number)
        {
            this.Number = number;
        }

        /// <summary>
        /// Template metodas, kurio veiksmai skirsis pagal tai, kaip paveldinti klasė apsirašys metodus esančius jo viduje
        /// </summary>
        public string InterpretValue()
        {
            if (Number != 0)
            {
                string interpretation = "";
                interpretation = interpretation + FirstMethod(Number);
                interpretation = interpretation + SecondMethod(Number);

                return HandleInterpretation(interpretation, Number);
            }
            else
            {
                return "no value was given, or the value is equal to 0";
            }
        }


        public abstract string FirstMethod(int number);
        public abstract string SecondMethod(int number);
        public abstract string HandleInterpretation(string interpretation, int number);

    }
}
