﻿using System;
using System.Collections.Generic;

namespace WithDI
{
    public class RunnerService
    {
        private readonly SneakyBoxInterpreter sneakyBoxInterpreter;
        private readonly NumberDataProvider numberProvider;

        public RunnerService(SneakyBoxInterpreter sneakyBoxInterpreter, NumberDataProvider numberProvider)
        {
            this.sneakyBoxInterpreter = sneakyBoxInterpreter;
            this.numberProvider = numberProvider;
        }

        public void Run()
        {
            var numbers = numberProvider.GetData();
            var results = new List<string>();

            foreach (var number in numbers)
            {
                sneakyBoxInterpreter.SetNumber(number);
                results.Add(sneakyBoxInterpreter.InterpretValue());
            }

            Console.WriteLine(string.Join(Environment.NewLine, results));
            Console.Read();
        }
    }


}


