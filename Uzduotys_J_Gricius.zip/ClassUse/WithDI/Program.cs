﻿using Microsoft.Extensions.DependencyInjection;

namespace WithDI
{
    class Program
    {
        static void Main(string[] args)
        {
            var container = new ServiceCollection();

            container.AddSingleton<RunnerService>()
                .AddSingleton<SneakyBoxInterpreter>()
                .AddSingleton<NumberDataProvider>();

            var provider = container.BuildServiceProvider();
            var runner = provider.GetRequiredService<RunnerService>();
            runner.Run();
        }
    }

}


