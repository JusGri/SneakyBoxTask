﻿using System.Collections.Generic;

namespace WithDI
{
    public class NumberDataProvider
    {
        public IEnumerable<int> GetData()
        {
            int i = 1;
            while (i <= 100)
            {
                yield return i++;
            }
        }
    }


}


