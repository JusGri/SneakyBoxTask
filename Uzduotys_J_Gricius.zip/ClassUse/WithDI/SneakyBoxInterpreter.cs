﻿using ClassUse;

namespace WithDI
{
    public class SneakyBoxInterpreter : NumberInterpreter
    {
        public sealed override string FirstMethod(int number)
        {
            if (number % 3 == 0)
            {
                return "Sneaky";
            }
            else return "";
        }
        public sealed override string SecondMethod(int number)
        {
            if (number % 5 == 0)
            {
                return "Box";
            }
            else return "";
        }
        public sealed override string HandleInterpretation(string interpretation, int number)
        {
            if (interpretation != "")
            {
                return interpretation;
            }
            else
            {
                return number.ToString();
            }
        }
    }


}


